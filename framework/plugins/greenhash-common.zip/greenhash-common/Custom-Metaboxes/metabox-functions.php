<?php
/**
 * Include and setup custom metaboxes and fields.
 *
 * @category YourThemeOrPlugin
 * @package  Metaboxes
 * @license  http://www.opensource.org/licenses/gpl-license.php GPL v2.0 (or later)
 * @link     https://github.com/jaredatch/Custom-Metaboxes-and-Fields-for-WordPress
 */

add_filter( 'cmb_meta_boxes', 'cmb_sample_metaboxes' );
/**
 * Define the metabox and field configurations.
 *
 * @param  array $meta_boxes
 * @return array
 */
$textdomain = "greenhash";
function cmb_sample_metaboxes( array $meta_boxes ) {

	// Start with an underscore to hide fields from custom fields list
	$prefix = '_cmb_';
	
    $meta_boxes[] = array(
        'id'         => 'page_setting',
        'title'      => 'Page Setting',
        'pages'      => array('page'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
        )
    );

   

    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('post'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Content',
                'desc' => 'Input content name',
                'default' => '',
                'id' => $prefix . 'content_name',
                'type' => 'text'
            ), 
            array(
                'name' => 'Facebook',
                'desc' => 'Input link facebook',
                'default' => '',
                'id' => $prefix . 'single_facebook',
                'type' => 'text'
            ), 
            array(
                'name' => 'Twitter',
                'desc' => 'Input link twitter',
                'default' => '',
                'id' => $prefix . 'single_twitter',
                'type' => 'text'
            ),
            array(
                'name' => 'Instagram',
                'desc' => 'Input link Instagram',
                'default' => '',
                'id' => $prefix . 'single_instagram',
                'type' => 'text'
            ),
            array(
                'name' => 'Google',
                'desc' => 'Input link Google',
                'default' => '',
                'id' => $prefix . 'single_google',
                'type' => 'text'
            ),
            array(
                'name' => 'Video',
                'desc' => 'Link Video',
                'default' => '',
                'id' => $prefix . 'single_video',
                'type' => 'text'
            ),
            array(
                'name' => 'Audio',
                'desc' => 'Link audio',
                'default' => '',
                'id' => $prefix . 'single_audio',
                'type' => 'textarea'
            ),
            array(
                'name' => 'Recent Title',
                'desc' => 'Input Recent Title',
                'default' => '',
                'id' => $prefix . 'recent_title',
                'type' => 'text'
            ), 
            array(
                'name' => 'Recent Image',
                'desc' => 'Image Upload',
                'default' => '',
                'id' => $prefix . 'recent_image',
                'type' => 'file'
            ),
            array(
                'name' => 'Home Title',
                'desc' => 'Input Home Title',
                'default' => '',
                'id' => $prefix . 'home_title',
                'type' => 'text'
            ), 
            array(
                'name' => 'Home Image',
                'desc' => 'Home Upload',
                'default' => '',
                'id' => $prefix . 'home_image',
                'type' => 'file'
            ),
        )
    );


    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('portfolio'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Large Image',
                'desc' => 'Image Upload',
                'default' => '',
                'id' => $prefix . 'portfolio_image',
                'type' => 'file'
            ),
            array(
                'name' => 'Portfolio Subtitle',
                'desc' => 'Input Portfolio Subtitle',
                'default' => '',
                'id' => $prefix . 'portfolio_subtitle',
                'type' => 'text'
            ), 
        )
    );


    $meta_boxes[] = array(
        'id'         => 'post_setting',
        'title'      => 'Post Setting',
        'pages'      => array('event'), // Post type
        'context'    => 'normal',
        'priority'   => 'high',
        'show_names' => true, // Show field names on the left
        //'show_on'    => array( 'key' => 'id', 'value' => array( 2, ), ), // Specific post IDs to display this metabox
        'fields' => array(
            array(
                'name' => 'Event Title',
                'desc' => 'Input Event Title',
                'default' => '',
                'id' => $prefix . 'event_title',
                'type' => 'text'
            ), 
            array(
                'name' => 'Event Excerpt',
                'desc' => 'Input Event Excerpt',
                'default' => '',
                'id' => $prefix . 'event_excerpt',
                'type' => 'text'
            ), 
            array(
                'name' => 'Event Price',
                'desc' => 'Input Event Price',
                'default' => '',
                'id' => $prefix . 'event_price',
                'type' => 'text'
            ), 
            array(
                'name' => 'Event Author',
                'desc' => 'Input Event Author',
                'default' => '',
                'id' => $prefix . 'event_author',
                'type' => 'text'
            ), 
            array(
                'name' => 'Event Address',
                'desc' => 'Input Event Address',
                'default' => '',
                'id' => $prefix . 'event_address',
                'type' => 'text'
            ), 
            array(
                'name' => 'Event Days',
                'desc' => 'Input Event Days',
                'default' => '',
                'id' => $prefix . 'event_days',
                'type' => 'text'
            ), 
            array(
                'name' => 'Event Time',
                'desc' => 'Input Event Time',
                'default' => '',
                'id' => $prefix . 'event_time',
                'type' => 'text'
            ), 
            array(
                'name' => 'Event Time 2',
                'desc' => 'Input Event Time 2',
                'default' => '',
                'id' => $prefix . 'event_time2',
                'type' => 'text'
            ),
        )
    );


    
    // Add other metaboxes as needed
    
	return $meta_boxes;
}

add_action( 'init', 'cmb_initialize_cmb_meta_boxes', 9999 );
/**
 * Initialize the metabox class.
 */
function cmb_initialize_cmb_meta_boxes() {

	if ( ! class_exists( 'cmb_Meta_Box' ) )
		require_once 'init.php';

} 

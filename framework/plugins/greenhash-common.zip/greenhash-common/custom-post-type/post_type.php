<?php
// register post type Portfolio

add_action( 'init', 'register_greenhash_Portfolio' );
function register_greenhash_Portfolio() {
    
    $labels = array( 
        'name' => __( 'Portfolio', 'greenhash' ),
        'singular_name' => __( 'Portfolio', 'greenhash' ),
        'add_new' => __( 'Add New Portfolio', 'greenhash' ),
        'add_new_item' => __( 'Add New Portfolio', 'greenhash' ),
        'edit_item' => __( 'Edit Portfolio', 'greenhash' ),
        'new_item' => __( 'New Portfolio', 'greenhash' ),
        'view_item' => __( 'View Portfolio', 'greenhash' ),
        'search_items' => __( 'Search Portfolio', 'greenhash' ),
        'not_found' => __( 'No Portfolio found', 'greenhash' ),
        'not_found_in_trash' => __( 'No Portfolio found in Trash', 'greenhash' ),
        'parent_item_colon' => __( 'Parent Portfolio:', 'greenhash' ),
        'menu_name' => __( 'Portfolio', 'greenhash' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Portfolio',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Portfolio', 'type' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon'     => 'dashicons-editor-paste-text',
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_style' => 'post'
    );

    register_post_type( 'Portfolio', $args );
}
add_action( 'init', 'create_PortfolioType_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_PortfolioType_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type', 'greenhash' ),
    'singular_name' => __( 'Type', 'greenhash' ),
    'search_items' =>  __( 'Search Type','greenhash' ),
    'all_items' => __( 'All Type','greenhash' ),
    'parent_item' => __( 'Parent Type','greenhash' ),
    'parent_item_colon' => __( 'Parent Type:','greenhash' ),
    'edit_item' => __( 'Edit Type','greenhash' ), 
    'update_item' => __( 'Update Type','greenhash' ),
    'add_new_item' => __( 'Add New Type','greenhash' ),
    'new_item_name' => __( 'New Type Name','greenhash' ),
    'menu_name' => __( 'Type','greenhash' ),
  );     

// Now register the taxonomy

  register_taxonomy('type',array('Portfolio',), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));

}


add_action( 'init', 'register_greenhash_Event' );
function register_greenhash_Event() {
    
    $labels = array( 
        'name' => __( 'Event', 'greenhash' ),
        'singular_name' => __( 'Event', 'greenhash' ),
        'add_new' => __( 'Add New Event', 'greenhash' ),
        'add_new_item' => __( 'Add New Event', 'greenhash' ),
        'edit_item' => __( 'Edit Event', 'greenhash' ),
        'new_item' => __( 'New Event', 'greenhash' ),
        'view_item' => __( 'View Event', 'greenhash' ),
        'search_items' => __( 'Search Event', 'greenhash' ),
        'not_found' => __( 'No Event found', 'greenhash' ),
        'not_found_in_trash' => __( 'No Event found in Trash', 'greenhash' ),
        'parent_item_colon' => __( 'Parent Event:', 'greenhash' ),
        'menu_name' => __( 'Event', 'greenhash' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Event',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Event', 'type1' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-groups', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_style' => 'post'
    );

    register_post_type( 'Event', $args );
}
add_action( 'init', 'create_EventType_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_EventType_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type', 'greenhash' ),
    'singular_name' => __( 'Type', 'greenhash' ),
    'search_items' =>  __( 'Search Type','greenhash' ),
    'all_items' => __( 'All Type','greenhash' ),
    'parent_item' => __( 'Parent Type','greenhash' ),
    'parent_item_colon' => __( 'Parent Type:','greenhash' ),
    'edit_item' => __( 'Edit Type','greenhash' ), 
    'update_item' => __( 'Update Type','greenhash' ),
    'add_new_item' => __( 'Add New Type','greenhash' ),
    'new_item_name' => __( 'New Type Name','greenhash' ),
    'menu_name' => __( 'Type','greenhash' ),
  );     

// Now register the taxonomy

  register_taxonomy('type1',array('Event',), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type1' ),
  ));


}


add_action( 'init', 'register_greenhash_Service' );
function register_greenhash_Service() {
    
    $labels = array( 
        'name' => __( 'Service', 'greenhash' ),
        'singular_name' => __( 'Service', 'greenhash' ),
        'add_new' => __( 'Add New Service', 'greenhash' ),
        'add_new_item' => __( 'Add New Service', 'greenhash' ),
        'edit_item' => __( 'Edit Service', 'greenhash' ),
        'new_item' => __( 'New Service', 'greenhash' ),
        'view_item' => __( 'View Service', 'greenhash' ),
        'search_items' => __( 'Search Service', 'greenhash' ),
        'not_found' => __( 'No Service found', 'greenhash' ),
        'not_found_in_trash' => __( 'No Service found in Trash', 'greenhash' ),
        'parent_item_colon' => __( 'Parent Service:', 'greenhash' ),
        'menu_name' => __( 'Service', 'greenhash' ),
    );

    $args = array( 
        'labels' => $labels,
        'hierarchical' => true,
        'description' => 'List Service',
        'supports' => array( 'title', 'editor', 'thumbnail', 'comments'),
        'taxonomies' => array( 'Service', 'type2' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 5,
        'menu_icon' => 'dashicons-hammer', 
        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => true,
        'capability_style' => 'post'
    );

    register_post_type( 'Service', $args );
}
add_action( 'init', 'create_ServiceType_hierarchical_taxonomy', 0 );

//create a custom taxonomy name it Skillss for your posts

function create_ServiceType_hierarchical_taxonomy() {

// Add new taxonomy, make it hierarchical like Skills
//first do the translations part for GUI

  $labels = array(
    'name' => __( 'Type', 'greenhash' ),
    'singular_name' => __( 'Type', 'greenhash' ),
    'search_items' =>  __( 'Search Type','greenhash' ),
    'all_items' => __( 'All Type','greenhash' ),
    'parent_item' => __( 'Parent Type','greenhash' ),
    'parent_item_colon' => __( 'Parent Type:','greenhash' ),
    'edit_item' => __( 'Edit Type','greenhash' ), 
    'update_item' => __( 'Update Type','greenhash' ),
    'add_new_item' => __( 'Add New Type','greenhash' ),
    'new_item_name' => __( 'New Type Name','greenhash' ),
    'menu_name' => __( 'Type','greenhash' ),
  );     

// Now register the taxonomy

  register_taxonomy('type2',array('Service',), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type2' ),
  ));


}
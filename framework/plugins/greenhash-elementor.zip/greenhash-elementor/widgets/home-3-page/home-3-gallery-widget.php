<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class Home3Gallery extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'home-3-gallery';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'Home 3 - Gallery Widget', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-favorite';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'home-3-page' ];
	}

	public function get_keywords() {
		return [ 'gallery' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_gallery',
			[
				'label' => esc_html__( 'Gallery Area', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'post_number',
			[
		        'label'       => __( 'Post Number', 'bdevs-elementor' ),
		        'type'        => Controls_Manager::TEXT,
		        'placeholder' => __( 'Post Number', 'bdevs-elementor' ),
		        'default'     => __( '6', 'bdevs-elementor' ),
		        'label_block' => true,
		    ]
		);

		$this->add_control(
			'post_order',
			[
				'label'     => esc_html__( 'Post Order', 'bdevs-elementor' ),
				'type'      => Controls_Manager::SELECT,
				'options'   => [
					'asc'  => esc_html__( 'ASC', 'bdevs-elementor' ),
					'desc' => esc_html__( 'DESC', 'bdevs-elementor' ),
				],
				'default'   => 'asc',
			]
		);

		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);

		$this->add_control(
			'show_heading',
			[
				'label'   => esc_html__( 'Show Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	

		$this->add_control(
			'show_sub_heading',
			[
				'label'   => esc_html__( 'Show Sub Heading', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	


		$this->add_control(
			'show_content',
			[
				'label'   => esc_html__( 'Show Content', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		?>

		<section class="gallery-section pb-100 pt-130">

			<div class="container">

				<div class="row">

					<div class="col-xl-12">

						<div class="gallery-menu text-center">

							<button class="active" data-filter="*"><?php echo esc_html__( 'Show All', 'greenhash' ); ?></button>

							<?php  $categories = get_terms('type'); 
							foreach( (array)$categories as $categorie){
								$cat_name = $categorie->name; 
								$cat_slug = $categorie->slug;
								?>
								<button data-filter=".<?php echo $cat_slug ?>"><?php echo $cat_name ?></button>
							<?php } ?>

						</div>

					</div>

				</div>

				<div class="row grid">

						<?php 
						$order = $settings['post_order'];
						$post_number = $settings['post_number'];
						$wp_query = new \WP_Query(array('posts_per_page' => $post_number,'post_type' => 'portfolio',  'orderby' => 'ID', 'order' => $order));
						$i = 0;
						while ($wp_query -> have_posts()) : $wp_query -> the_post(); 
							$cates = get_the_terms(get_the_ID(),'type');

							$cate_name ='';

							$cate_slug ='';

							foreach((array)$cates as $cate){

								if(count($cates)>0){

									$cate_name .= $cate->name.' ';

									$cate_slug .= $cate->slug.' ';     

								} 

							} 

							$i++;
							$portfolio_image = get_post_meta(get_the_ID(),'_cmb_portfolio_image', true);  
							$portfolio_subtitle = get_post_meta(get_the_ID(),'_cmb_portfolio_subtitle', true);     
							?>

						<div class="col-xl-4 col-lg-6 col-md-6 grid-item <?php echo $cate_slug ?>">

							<div class="single-gallery mb-30">

								<div class="gallery-img">

									<img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="">

									<div class="gallery-overlay">

										<div class="gallery-content">

											<a href="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" class="popup-img"><span class="plus"></span></a>

											<h2 class="text-white"><?php the_title();?></h2>

											<h5 class="text-white"><?php echo esc_attr($portfolio_subtitle); ?></h5>

										</div>

									</div>

								</div>

							</div>

						</div>

					<?php endwhile; ?>

				</div>

			</div>

		</section>

	<?php
	}
}
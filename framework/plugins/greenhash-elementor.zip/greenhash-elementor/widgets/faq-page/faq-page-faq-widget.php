<?php
namespace BdevsElementor\Widget;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;

/**
 * Bdevs Elementor Widget.
 *
 * Elementor widget that inserts an embbedable content into the page, from any given URL.
 *
 * @since 1.0.0
 */
class FaqPageFaq extends \Elementor\Widget_Base {

	/**
	 * Get widget name.
	 *
	 * Retrieve Bdevs Elementor widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'faq-page-faq';
	}

	/**
	 * Get widget title.
	 *
	 * Retrieve Bdevs Elementor widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */
	public function get_title() {
		return __( 'FAQ Page - FAQ Widget', 'bdevs-elementor' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve Bdevs Slider widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-favorite';
	}

	/**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the Bdevs Slider widget belongs to.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
		return [ 'faq-page' ];
	}

	public function get_keywords() {
		return [ 'FAQ' ];
	}

	public function get_script_depends() {
		return [ 'bdevs-elementor'];
	}

	// BDT Position
	protected function element_pack_position() {
	    $position_options = [
	        ''              => esc_html__('Default', 'bdevs-elementor'),
	        'top-left'      => esc_html__('Top Left', 'bdevs-elementor') ,
	        'top-center'    => esc_html__('Top Center', 'bdevs-elementor') ,
	        'top-right'     => esc_html__('Top Right', 'bdevs-elementor') ,
	        'center'        => esc_html__('Center', 'bdevs-elementor') ,
	        'center-left'   => esc_html__('Center Left', 'bdevs-elementor') ,
	        'center-right'  => esc_html__('Center Right', 'bdevs-elementor') ,
	        'bottom-left'   => esc_html__('Bottom Left', 'bdevs-elementor') ,
	        'bottom-center' => esc_html__('Bottom Center', 'bdevs-elementor') ,
	        'bottom-right'  => esc_html__('Bottom Right', 'bdevs-elementor') ,
	    ];

	    return $position_options;
	}

	protected function _register_controls() {
		$this->start_controls_section(
			'section_faq',
			[
				'label' => esc_html__( 'FAQ Area 1', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'heading',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tabs',
			[
				'label' => esc_html__( 'FAQ Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [
					[
						'name'        => 'faq_type',
						'label'     => esc_html__( 'FAQ Type', 'bdevs-elementor' ),
						'type'      => Controls_Manager::SELECT,
						'dynamic' => [ 'active' => true ],
						'options'   => [
							'1'  => esc_html__( 'First Item', 'bdevs-elementor' ),
							'2'  => esc_html__( 'Normal Item', 'bdevs-elementor' ),
							'3'  => esc_html__( 'Last Item', 'bdevs-elementor' ),
						],
						'default'   => '2',
					],		
					[
						'name'        => 'tab_title',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'id_1',
						'label'       => esc_html__( 'Tab ID 1', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab ID 1' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'id_2',
						'label'       => esc_html__( 'Tab ID 2', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab ID 2' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'tab_content',
						'label'       => esc_html__( 'Content', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab Content' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'section_faq_2',
			[
				'label' => esc_html__( 'FAQ Area 2', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'heading_2',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tabs_2',
			[
				'label' => esc_html__( 'FAQ Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [
					[
						'name'        => 'faq_type',
						'label'     => esc_html__( 'FAQ Type', 'bdevs-elementor' ),
						'type'      => Controls_Manager::SELECT,
						'dynamic' => [ 'active' => true ],
						'options'   => [
							'1'  => esc_html__( 'First Item', 'bdevs-elementor' ),
							'2'  => esc_html__( 'Normal Item', 'bdevs-elementor' ),
							'3'  => esc_html__( 'Last Item', 'bdevs-elementor' ),
						],
						'default'   => '2',
					],		
					[
						'name'        => 'tab_title',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'id_1',
						'label'       => esc_html__( 'Tab ID 1', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab ID 1' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'id_2',
						'label'       => esc_html__( 'Tab ID 2', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab ID 2' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'tab_content',
						'label'       => esc_html__( 'Content', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab Content' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					
				],
			]
		);

		$this->end_controls_section();



		$this->start_controls_section(
			'section_faq_3',
			[
				'label' => esc_html__( 'FAQ Area 3', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'heading_3',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'tabs_3',
			[
				'label' => esc_html__( 'FAQ Items', 'bdevs-elementor' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [
					[
						'name'        => 'faq_type',
						'label'     => esc_html__( 'FAQ Type', 'bdevs-elementor' ),
						'type'      => Controls_Manager::SELECT,
						'dynamic' => [ 'active' => true ],
						'options'   => [
							'1'  => esc_html__( 'First Item', 'bdevs-elementor' ),
							'2'  => esc_html__( 'Normal Item', 'bdevs-elementor' ),
							'3'  => esc_html__( 'Last Item', 'bdevs-elementor' ),
						],
						'default'   => '2',
					],		
					[
						'name'        => 'tab_title',
						'label'       => esc_html__( 'Title', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab Title' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'id_1',
						'label'       => esc_html__( 'Tab ID 1', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab ID 1' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'id_2',
						'label'       => esc_html__( 'Tab ID 2', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXT,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab ID 2' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					[
						'name'        => 'tab_content',
						'label'       => esc_html__( 'Content', 'bdevs-elementor' ),
						'type'        => Controls_Manager::TEXTAREA,
						'dynamic'     => [ 'active' => true ],
						'default'     => esc_html__( 'Tab Content' , 'bdevs-elementor' ),
						'label_block' => true,
					],
					
				],
			]
		);

		$this->end_controls_section();




		$this->start_controls_section(
			'section_contact_form',
			[
				'label' => esc_html__( 'Contact Form Area', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'heading_4',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'contact_form',
			[
				'label'       => __( 'Contact Form', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your contact form', 'bdevs-elementor' ),
				'default'     => __( 'It is Contact Form', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		
		$this->end_controls_section();




		$this->start_controls_section(
			'section_contact_us',
			[
				'label' => esc_html__( 'Contact Us Area', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'bdevs-elementor' ),
				'type'    => Controls_Manager::MEDIA,
				'dynamic' => [ 'active' => true ],
				'description' => esc_html__( 'Add Your Features Image', 'bdevs-elementor' ),
			]
		);

		$this->add_control(
			'heading_5',
			[
				'label'       => __( 'Heading', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your heading', 'bdevs-elementor' ),
				'default'     => __( 'It is Heading', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'content',
			[
				'label'       => __( 'Content', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your content', 'bdevs-elementor' ),
				'default'     => __( 'It is Content', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'link',
			[
				'label'       => __( 'Link', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXTAREA,
				'placeholder' => __( 'Enter your link', 'bdevs-elementor' ),
				'default'     => __( 'It is Link', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'button',
			[
				'label'       => __( 'Button', 'bdevs-elementor' ),
				'type'        => Controls_Manager::TEXT,
				'placeholder' => __( 'Enter your button', 'bdevs-elementor' ),
				'default'     => __( 'It is Button', 'bdevs-elementor' ),
				'label_block' => true,
			]
		);

		
		$this->end_controls_section();



		$this->start_controls_section(
			'section_content_layout',
			[
				'label' => esc_html__( 'Layout', 'bdevs-elementor' ),
			]
		);

		$this->add_responsive_control(
			'align',
			[
				'label'   => esc_html__( 'Alignment', 'bdevs-elementor' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justified', 'bdevs-elementor' ),
						'icon'  => 'fa fa-align-justify',
					],
				],
				'prefix_class' => 'elementor%s-align-',
				'description'  => 'Use align to match position',
				'default'      => 'left',
			]
		);

		$this->add_control(
			'show_faq_1',
			[
				'label'   => esc_html__( 'Show FAQ Area 1', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	

		$this->add_control(
			'show_faq_2',
			[
				'label'   => esc_html__( 'Show FAQ Area 2', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);	


		$this->add_control(
			'show_faq_3',
			[
				'label'   => esc_html__( 'Show FAQ Area 3', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_contact_form',
			[
				'label'   => esc_html__( 'Show Contact Form', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_contact_us',
			[
				'label'   => esc_html__( 'Show Contact Us', 'bdevs-elementor' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->end_controls_section();

	}

	public function render() {
		$settings  = $this->get_settings_for_display();
		?>

		<section class="service-section theme-bg-2 pt-130 pb-100">

			<div class="container">

				<div class="row">

					<div class="col-xl-8 col-lg-8">

						<div class="service-details-wrapper">

							<?php if ( $settings['show_faq_1'] ): ?>

							<div class="details-box mb-40">

								<?php if ( '' !== $settings['heading'] ) : ?>
								<h2 class="mb-30"><?php echo wp_kses_post($settings['heading']); ?></h2>
								<?php endif; ?>

								<div class="ser-details-box-faq">

									<div class="accordion" id="accordionExample">

										<?php foreach ( $settings['tabs'] as $item ) : ?>

											<?php if( wp_kses_post($item['faq_type']) == '1'): ?>

										<div class="card mb-15">

											<div class="card-header" id="<?php echo wp_kses_post($item['id_1']); ?>">
												<?php if ( '' !== $item['tab_title'] ) : ?>
												<h5 class="mb-0">

													<button class="faq-btn" type="button"

													data-toggle="collapse" data-target="#<?php echo wp_kses_post($item['id_2']); ?>"

													aria-expanded="true" aria-controls="<?php echo wp_kses_post($item['id_2']); ?>">

														<i class="far fa-plus"></i> <?php echo wp_kses_post($item['tab_title']); ?>

													</button>

												</h5>
												<?php endif; ?>

											</div>

											<div id="<?php echo wp_kses_post($item['id_2']); ?>" class="collapse show" aria-labelledby="<?php echo wp_kses_post($item['id_1']); ?>"

											data-parent="#accordionExample">

											<?php if ( '' !== $item['tab_content'] ) : ?>

											<div class="card-body">

												<?php echo wp_kses_post($item['tab_content']); ?>

											</div>

											<?php endif; ?>

										</div>

									</div>

									<?php elseif( wp_kses_post($item['faq_type']) == '2'): ?>

										<div class="card mb-15">

											<div class="card-header" id="<?php echo wp_kses_post($item['id_1']); ?>">
												<?php if ( '' !== $item['tab_title'] ) : ?>
												<h5 class="mb-0">

													<button class="faq-btn" type="button"

													data-toggle="collapse" data-target="#<?php echo wp_kses_post($item['id_2']); ?>"

													aria-expanded="true" aria-controls="<?php echo wp_kses_post($item['id_2']); ?>">

														<i class="far fa-plus"></i> <?php echo wp_kses_post($item['tab_title']); ?>

													</button>

												</h5>
												<?php endif; ?>

											</div>

											<div id="<?php echo wp_kses_post($item['id_2']); ?>" class="collapse" aria-labelledby="<?php echo wp_kses_post($item['id_1']); ?>"

											data-parent="#accordionExample">

											<?php if ( '' !== $item['tab_content'] ) : ?>

											<div class="card-body">

												<?php echo wp_kses_post($item['tab_content']); ?>

											</div>

											<?php endif; ?>

										</div>

									</div>

									<?php elseif( wp_kses_post($item['faq_type']) == '3'): ?>

										<div class="card">

											<div class="card-header" id="<?php echo wp_kses_post($item['id_1']); ?>">
												<?php if ( '' !== $item['tab_title'] ) : ?>

													<h5 class="mb-0">

														<button class="faq-btn" type="button"

														data-toggle="collapse" data-target="#<?php echo wp_kses_post($item['id_2']); ?>"

														aria-expanded="true" aria-controls="<?php echo wp_kses_post($item['id_2']); ?>">

															<i class="far fa-plus"></i> <?php echo wp_kses_post($item['tab_title']); ?>

														</button>

													</h5>

												<?php endif; ?>

											</div>

											<div id="<?php echo wp_kses_post($item['id_2']); ?>" class="collapse" aria-labelledby="<?php echo wp_kses_post($item['id_1']); ?>"

											data-parent="#accordionExample">

												<?php if ( '' !== $item['tab_content'] ) : ?>

													<div class="card-body">

														<?php echo wp_kses_post($item['tab_content']); ?>

													</div>

												<?php endif; ?>

											</div>

										</div>

									<?php endif; ?>

									<?php endforeach; ?>

								</div>

							</div>

						</div>

						<?php endif; ?>

						<?php if ( $settings['show_faq_2'] ): ?>

						<div class="details-box mb-40">

							<?php if ( '' !== $settings['heading_2'] ) : ?>
								<h2 class="mb-30"><?php echo wp_kses_post($settings['heading_2']); ?></h2>
							<?php endif; ?>

							<div class="ser-details-box-faq">

								<div class="accordion" id="accordionExample2">

									<?php foreach ( $settings['tabs_2'] as $item ) : ?>

									<?php if( wp_kses_post($item['faq_type']) == '1'): ?>

									<div class="card mb-15">

										<div class="card-header" id="<?php echo wp_kses_post($item['id_1']); ?>">

											<?php if ( '' !== $item['tab_title'] ) : ?>
											<h5 class="mb-0">

												<button class="faq-btn" type="button"

												data-toggle="collapse" data-target="#<?php echo wp_kses_post($item['id_2']); ?>"

												aria-expanded="true" aria-controls="<?php echo wp_kses_post($item['id_2']); ?>">

												<i class="far fa-plus"></i> <?php echo wp_kses_post($item['tab_title']); ?>
											</button>

										</h5>

										<?php endif; ?>

									</div>



									<div id="<?php echo wp_kses_post($item['id_2']); ?>" class="collapse show" aria-labelledby="<?php echo wp_kses_post($item['id_1']); ?>"

									data-parent="#accordionExample2">

									<?php if ( '' !== $item['tab_content'] ) : ?>

										<div class="card-body">

											<?php echo wp_kses_post($item['tab_content']); ?>

										</div>

									<?php endif; ?>

								</div>

							</div>

							<?php elseif( wp_kses_post($item['faq_type']) == '2'): ?>

								<div class="card mb-15">

										<div class="card-header" id="<?php echo wp_kses_post($item['id_1']); ?>">

											<?php if ( '' !== $item['tab_title'] ) : ?>

											<h5 class="mb-0">

												<button class="faq-btn" type="button"

												data-toggle="collapse" data-target="#<?php echo wp_kses_post($item['id_2']); ?>"

												aria-expanded="true" aria-controls="<?php echo wp_kses_post($item['id_2']); ?>">

												<i class="far fa-plus"></i> <?php echo wp_kses_post($item['tab_title']); ?>

											</button>

										</h5>

										<?php endif; ?>

									</div>

									<div id="<?php echo wp_kses_post($item['id_2']); ?>" class="collapse" aria-labelledby="<?php echo wp_kses_post($item['id_1']); ?>"

									data-parent="#accordionExample2">

									<?php if ( '' !== $item['tab_content'] ) : ?>

										<div class="card-body">

											<?php echo wp_kses_post($item['tab_content']); ?>

										</div>

									<?php endif; ?>

								</div>

							</div>

							<?php elseif( wp_kses_post($item['faq_type']) == '3'): ?>

								<div class="card">

										<div class="card-header" id="<?php echo wp_kses_post($item['id_1']); ?>">

											<?php if ( '' !== $item['tab_title'] ) : ?>

											<h5 class="mb-0">

												<button class="faq-btn" type="button"

												data-toggle="collapse" data-target="#<?php echo wp_kses_post($item['id_2']); ?>"

												aria-expanded="true" aria-controls="<?php echo wp_kses_post($item['id_2']); ?>">

												<i class="far fa-plus"></i> <?php echo wp_kses_post($item['tab_title']); ?>

											</button>

										</h5>

										<?php endif; ?>

									</div>

									<div id="<?php echo wp_kses_post($item['id_2']); ?>" class="collapse" aria-labelledby="<?php echo wp_kses_post($item['id_1']); ?>"

									data-parent="#accordionExample2">

									<?php if ( '' !== $item['tab_content'] ) : ?>

										<div class="card-body">

											<?php echo wp_kses_post($item['tab_content']); ?>

										</div>

									<?php endif; ?>

								</div>

							</div>

							<?php endif; ?>

							<?php endforeach; ?>

						</div>

					</div>

				</div>

				<?php endif; ?>

				<?php if ( $settings['show_faq_3'] ): ?>

				<div class="details-box mb-40">

					<?php if ( '' !== $settings['heading_3'] ) : ?>
						<h2 class="mb-30"><?php echo wp_kses_post($settings['heading_3']); ?></h2>
					<?php endif; ?>

					<div class="ser-details-box-faq">

						<div class="accordion" id="accordionExample3">

							<?php foreach ( $settings['tabs_3'] as $item ) : ?>

								<?php if( wp_kses_post($item['faq_type']) == '1'): ?>

							<div class="card mb-15">

								<div class="card-header" id="<?php echo wp_kses_post($item['id_1']); ?>">

									<?php if ( '' !== $item['tab_title'] ) : ?>

									<h5 class="mb-0">

										<button class="faq-btn" type="button"

										data-toggle="collapse" data-target="#<?php echo wp_kses_post($item['id_2']); ?>"

										aria-expanded="true" aria-controls="<?php echo wp_kses_post($item['id_2']); ?>">

										<i class="far fa-plus"></i> <?php echo wp_kses_post($item['tab_title']); ?>

									</button>

								</h5>

								<?php endif; ?>

							</div>



							<div id="<?php echo wp_kses_post($item['id_2']); ?>" class="collapse show" aria-labelledby="<?php echo wp_kses_post($item['id_1']); ?>"

							data-parent="#accordionExample3">

							<?php if ( '' !== $item['tab_content'] ) : ?>

								<div class="card-body">

									<?php echo wp_kses_post($item['tab_content']); ?>

								</div>

							<?php endif; ?>

						</div>

					</div>

					<?php elseif( wp_kses_post($item['faq_type']) == '2'): ?>

						<div class="card mb-15">

								<div class="card-header" id="<?php echo wp_kses_post($item['id_1']); ?>">

									<?php if ( '' !== $item['tab_title'] ) : ?>

									<h5 class="mb-0">

										<button class="faq-btn" type="button"

										data-toggle="collapse" data-target="#<?php echo wp_kses_post($item['id_2']); ?>"

										aria-expanded="true" aria-controls="<?php echo wp_kses_post($item['id_2']); ?>">

										<i class="far fa-plus"></i> <?php echo wp_kses_post($item['tab_title']); ?>

									</button>

								</h5>

								<?php endif; ?>

							</div>



							<div id="<?php echo wp_kses_post($item['id_2']); ?>" class="collapse" aria-labelledby="<?php echo wp_kses_post($item['id_1']); ?>"

							data-parent="#accordionExample3">

							<?php if ( '' !== $item['tab_content'] ) : ?>

								<div class="card-body">

									<?php echo wp_kses_post($item['tab_content']); ?>

								</div>

							<?php endif; ?>

						</div>

					</div>

					<?php elseif( wp_kses_post($item['faq_type']) == '3'): ?>

						<div class="card">

								<div class="card-header" id="<?php echo wp_kses_post($item['id_1']); ?>">

									<?php if ( '' !== $item['tab_title'] ) : ?>

									<h5 class="mb-0">

										<button class="faq-btn" type="button"

										data-toggle="collapse" data-target="#<?php echo wp_kses_post($item['id_2']); ?>"

										aria-expanded="true" aria-controls="<?php echo wp_kses_post($item['id_2']); ?>">

										<i class="far fa-plus"></i> <?php echo wp_kses_post($item['tab_title']); ?>

									</button>

								</h5>

								<?php endif; ?>

							</div>



							<div id="<?php echo wp_kses_post($item['id_2']); ?>" class="collapse" aria-labelledby="<?php echo wp_kses_post($item['id_1']); ?>"

							data-parent="#accordionExample3">

							<?php if ( '' !== $item['tab_content'] ) : ?>

								<div class="card-body">

									<?php echo wp_kses_post($item['tab_content']); ?>

								</div>

							<?php endif; ?>

						</div>

					</div>

					<?php endif; ?>

					<?php endforeach; ?>

				</div>

			</div>

		</div>

		<?php endif; ?>

	</div>

</div>



<div class="col-xl-4 col-lg-4">

	<div class="sidebar-wrapper">

		<?php if ( $settings['show_contact_form'] ): ?>

		<div class="sidebar-box mb-40">

			<?php if ( '' !== $settings['heading_4'] ): ?>
				<h4 class="mb-35"><?php echo wp_kses_post($settings['heading_4']); ?></h4>
			<?php endif; ?>

			<?php if ( '' !== $settings['contact_form'] ) : ?>
				<?php echo do_shortcode(wp_kses_post($settings['contact_form'])); ?>
			<?php endif; ?>

		</div>

		<?php endif; ?>

		<?php if ( $settings['show_contact_us'] ): ?>

		<div class="sidebar-box-2">

			<?php if ( '' !== $settings['image']['url'] ) : ?>
			<div class="sidebar-box-content-wrapper position-relative img-bg bg-overlay" data-background="<?php echo wp_kses_post($settings['image']['url']); ?>">
			<?php endif; ?>

				<div class="sidebar-box-content">

					<?php if ( '' !== $settings['heading_5'] ) : ?>
					<h4><?php echo wp_kses_post($settings['heading_5']); ?> </h4>
					<?php endif; ?>

					<?php if ( '' !== $settings['content'] ) : ?>
					<p><?php echo wp_kses_post($settings['content']); ?></p>
					<?php endif; ?>

					<?php if ( '' !== $settings['button'] ) : ?>
					<a href="<?php echo wp_kses_post($settings['link']); ?>" class="btn btn-border theme-btn2"><?php echo wp_kses_post($settings['button']); ?> <i class="far fa-long-arrow-right"></i> </a>
					<?php endif; ?>

				</div>

			</div>

		</div>

		<?php endif; ?>

	</div>

</div>

</div>

</div>

</section>

	<?php
	}
}
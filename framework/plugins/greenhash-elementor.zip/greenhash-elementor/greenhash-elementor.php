<?php
/**
 * Plugin Name: Greenhash Elementor
 * Description: Create unlimited widgets with Elementor Page Builder.
 * Plugin URI:  http://shtheme.net/plugins/greenhash-elementor/
 * Version:     1.0.0
 * Author:      Shtheme
 * Author URI:  http://shtheme.net
 * Text Domain: greenhash-elementor
 * Domain Path: /languages/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Main Bdevs Elementor Class
 *
 * The main class that initiates and runs the plugin.
 *
 * @since 1.0.0
 */
final class BdevsElementor {

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 *
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 *
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '5.5';

	/**
	 * Instance
	 *
	 * @since 1.0.0
	 *
	 * @access private
	 * @static
	 *
	 * @var BdevsElementor The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 *
	 * Ensures only one instance of the class is loaded or can be loaded.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 * @static
	 *
	 * @return BdevsElementor An instance of the class.
	 */
	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;

	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function __construct() {

		add_action( 'init', [ $this, 'i18n' ] );
		add_action( 'plugins_loaded', [ $this, 'init' ] );

	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 *
	 * Fired by `init` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function i18n() {

		load_plugin_textdomain( 'bdevs-elementor' );

	}

	/**
	 * Initialize the plugin
	 *
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}

		add_action( 'elementor/init', [ $this, 'add_elementor_category' ], 1 );

		// Add Plugin actions
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'register_frontend_scripts' ], 10 );

		// Register Widget Styles
		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'register_frontend_styles' ] );

		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );

		// Register controls
		//add_action( 'elementor/controls/controls_registered', [ $this, 'register_controls' ] );
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'bdevs-elementor' ),
			'<strong>' . esc_html__( 'Greenhash Elementor', 'bdevs-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bdevs-elementor' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bdevs-elementor' ),
			'<strong>' . esc_html__( 'Greenhash Elementor', 'bdevs-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'bdevs-elementor' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'bdevs-elementor' ),
			'<strong>' . esc_html__( 'Greenhash Elementor', 'bdevs-elementor' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'bdevs-elementor' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Add Elementor category.
	 */
	public function add_elementor_category() {
    	\Elementor\Plugin::instance()->elements_manager->add_category('home-1-page',
	      	array(
					'title' => __( 'Home 1 Page', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
	      	) 
	    );
	    \Elementor\Plugin::instance()->elements_manager->add_category('home-2-page',
	      	array(
					'title' => __( 'Home 2 Page', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
	      	) 
	    );
	    \Elementor\Plugin::instance()->elements_manager->add_category('home-3-page',
	      	array(
					'title' => __( 'Home 3 Page', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
	      	) 
	    );
	    \Elementor\Plugin::instance()->elements_manager->add_category('about-page',
	      	array(
					'title' => __( 'About Page', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
	      	) 
	    );
	    \Elementor\Plugin::instance()->elements_manager->add_category('services-page',
	      	array(
					'title' => __( 'Services Page', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
	      	) 
	    );
	    \Elementor\Plugin::instance()->elements_manager->add_category('team-page',
	      	array(
					'title' => __( 'Team Page', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
	      	) 
	    );
	    \Elementor\Plugin::instance()->elements_manager->add_category('faq-page',
	      	array(
					'title' => __( 'FAQ Page', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
	      	) 
	    );
	    \Elementor\Plugin::instance()->elements_manager->add_category('pricing-page',
	      	array(
					'title' => __( 'Pricing Page', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
	      	) 
	    );
	    \Elementor\Plugin::instance()->elements_manager->add_category('portfolio-page',
	      	array(
					'title' => __( 'Portfolio Page', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
	      	) 
	    );
	    \Elementor\Plugin::instance()->elements_manager->add_category('contact-page',
	      	array(
					'title' => __( 'Contact Page', 'bdevs-elementor' ),
					'icon'  => 'fa fa-plug',
	      	) 
	    );
	}

	/**
	* Register Frontend Scripts
	*
	*/
	public function register_frontend_scripts() {
	wp_register_script( 'bdevs-elementor', plugin_dir_url( __FILE__ ) . 'assets/js/bdevs-elementor.js', array( 'jquery' ), self::VERSION );
	}

	/**
	* Register Frontend styles
	*
	*/
	public function register_frontend_styles() {
	wp_register_style( 'bdevs-elementor', plugin_dir_url( __FILE__ ) . 'assets/css/bdevs-elementor.css', self::VERSION );
	}




	/**
	 * Init Widgets
	 *
	 * Include widgets files and register them
	 *
	 * @since 1.0.0
	 *
	 * @access public
	 */
	public function init_widgets() {

		// Include Widget files

		// Home 1
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-slider-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-welcome-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-about-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-services-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-video-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-features-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-event-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-who-we-are-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-team-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-portfolio-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-testimonials-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-1-page/home-1-blog-widget.php';
		// Home 2
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-slider-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-welcome-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-services-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-get-a-quote-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-our-skill-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-counter-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-testimonials-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-events-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-choose-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-contact-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-2-page/home-2-blog-widget.php';
		// Home 3
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-slider-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-features-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-welcome-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-services-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-quote-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-gallery-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-deal-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-contact-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-counter-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-testimonials-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/home-3-page/home-3-blog-widget.php';
		// About Page
		require_once plugin_dir_path( __FILE__ ) . 'widgets/about-page/about-page-header-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/about-page/about-page-about-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/about-page/about-page-team-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/about-page/about-page-video-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/about-page/about-page-testimonials-widget.php';
		// Services Page
		require_once plugin_dir_path( __FILE__ ) . 'widgets/services-page/services-page-services-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/services-page/services-page-services-2-widget.php';
		// Team Page
		require_once plugin_dir_path( __FILE__ ) . 'widgets/team-page/team-page-team-widget.php';
		// FAQ Page
		require_once plugin_dir_path( __FILE__ ) . 'widgets/faq-page/faq-page-faq-widget.php';
		// Pricing Page
		require_once plugin_dir_path( __FILE__ ) . 'widgets/pricing-page/pricing-page-pricing-widget.php';
		// Portfolio Page
		require_once plugin_dir_path( __FILE__ ) . 'widgets/portfolio-page/portfolio-page-gallery-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/portfolio-page/portfolio-page-gallery-2-widget.php';
		// Contact Page
		require_once plugin_dir_path( __FILE__ ) . 'widgets/contact-page/contact-page-address-widget.php';
		require_once plugin_dir_path( __FILE__ ) . 'widgets/contact-page/contact-page-contact-widget.php';


		// Register widget
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1Slider() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1Welcome() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1About() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1Services() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1Video() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1Features() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1Event() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1WhoWeAre() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1Team() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1Portfolio() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1Testimonials() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home1Blog() );
		// Home 2
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Slider() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Welcome() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Services() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Quote() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Skill() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Counter() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Testimonials() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Events() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Choose() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Contact() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home2Blog() );
		// Home 3
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Slider() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Features() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Welcome() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Services() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Quote() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Gallery() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Deal() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Contact() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Counter() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Testimonials() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\Home3Blog() );
		// About Page
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\AboutPageHeader() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\AboutPageAbout() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\AboutPageTeam() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\AboutPageVideo() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\AboutPageTestimonials() );
		// Services Page
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\ServicesPageServices() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\ServicesPageServices2() );
		// Team Page
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\TeamPageTeam() );
		// Faq Page
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\FaqPageFaq() );
		// Pricing Page
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\PricingPagePricing() );
		// Portfolio Page
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\PortfolioPageGallery() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\PortfolioPageGallery2() );
		// Contact Page
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\ContactPageAddress() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BdevsElementor\Widget\ContactPageContact() );
	}

	/** 
	 * register_controls description
	 * @return [type] [description]
	 */
	public function register_controls() {

		$controls_manager = \Elementor\Plugin::$instance->controls_manager;
		$controls_manager->register_control( 'slider-widget', new Test_Control1() );
	
	}

	/**
	 * Prints the Elementor Page content.
	 */
	public static function get_content( $id = 0 ) {
		if ( class_exists( '\ElementorPro\Plugin' ) ) {
			echo do_shortcode( '[elementor-template id="' . $id . '"]' );
		} else {
			echo \Elementor\Plugin::instance()->frontend->get_builder_content_for_display( $id );
		}
	}

}

BdevsElementor::instance();
